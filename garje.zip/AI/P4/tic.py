import numpy as np
import random
from time import sleep


def create_board():
    return np.array([[0, 0, 0],
                     [0, 0, 0],
                     [0, 0, 0]])


def possibilities(board):
    empty = []
    for i in range(3):
        for j in range(3):
            if board[i][j] == 0:
                empty.append((i, j))
    return empty


def random_place(board, player):
    positions = possibilities(board)
    move = random.choice(positions)
    board[move] = player
    return board


def row_win(board, player):
    for i in range(3):
        if all(board[i][j] == player for j in range(3)):
            return True
    return False


def col_win(board, player):
    for j in range(3):
        if all(board[i][j] == player for i in range(3)):
            return True
    return False


def diag_win(board, player):
    if all(board[i][i] == player for i in range(3)):
        return True
    if all(board[i][2 - i] == player for i in range(3)):
        return True
    return False


def evaluate(board):
    for player in [1, 2]:
        if row_win(board, player) or col_win(board, player) or diag_win(board, player):
            return player
    if np.all(board != 0):
        return -1
    return 0


def play_game():
    board = create_board()
    winner = 0
    move = 1

    print(board)
    sleep(1)

    while winner == 0:
        for player in [1, 2]:
            board = random_place(board, player)
            print(f"\nBoard after {move} move")
            print(board)
            sleep(1)
            move += 1

            winner = evaluate(board)
            if winner != 0:
                break

    return winner


print("Winner is:", play_game())

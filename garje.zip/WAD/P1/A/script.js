const loginForm = document.getElementById("loginForm");
const loginPage = document.getElementById("loginPage");
const dashboardPage = document.getElementById("dashboardPage");
const staffSection = document.getElementById("staffSection");
const studentSection = document.getElementById("studentSection");
const dashboardTitle = document.getElementById("dashboardTitle");
const dashboardText = document.getElementById("dashboardText");

loginForm.addEventListener("submit", function (e) {
  e.preventDefault();

  const role = document.getElementById("role").value;
  const username = document.getElementById("username").value;

  if (role === "staff") {
    loginPage.style.display = "none";
    dashboardPage.style.display = "block";
    staffSection.classList.remove("hidden");
    studentSection.classList.add("hidden");
    dashboardTitle.innerText = "Welcome Staff";
    dashboardText.innerText = "Upcoming student exams are shown below.";
  } else if (role === "student") {
    loginPage.style.display = "none";
    dashboardPage.style.display = "block";
    studentSection.classList.remove("hidden");
    staffSection.classList.add("hidden");
    dashboardTitle.innerText = "Welcome " + username;
    dashboardText.innerText = "Your syllabus subjects are shown below.";
  } else {
    alert("Please select a role.");
  }
});

function logoutUser() {
  dashboardPage.style.display = "none";
  loginPage.style.display = "flex";
  loginForm.reset();
}
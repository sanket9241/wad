let users = JSON.parse(localStorage.getItem("users")) || [];

const form = document.getElementById("registrationForm");
const message = document.getElementById("message");
const tableBody = document.getElementById("userTableBody");

if (form) {
  form.addEventListener("submit", async function (e) {
    e.preventDefault();

    const name = document.getElementById("name").value;
    const email = document.getElementById("email").value;
    const course = document.getElementById("course").value;

    const user = { name, email, course };

    users.push(user);
    localStorage.setItem("users", JSON.stringify(users));

    try {
      await fetch("https://jsonplaceholder.typicode.com/posts", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify(user)
      });

      message.innerText = "Registration successful!";
      form.reset();
    } catch (error) {
      message.innerText = "Data saved locally, POST request failed.";
    }
  });
}

if (tableBody) {
  users.forEach(function (user) {
    const row = document.createElement("tr");
    row.innerHTML = `
      <td>${user.name}</td>
      <td>${user.email}</td>
      <td>${user.course}</td>
    `;
    tableBody.appendChild(row);
  });
}